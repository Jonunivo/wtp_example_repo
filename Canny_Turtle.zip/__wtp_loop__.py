from runner import kill_all_tasks 
kill_all_tasks()